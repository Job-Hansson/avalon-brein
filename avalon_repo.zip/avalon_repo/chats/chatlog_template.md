# Chatlog Week WW YYYY

## Dag 1 — Maandag


## Dag 2 — Dinsdag


## Dag 3 — Woensdag


## Dag 4 — Donderdag


## Dag 5 — Vrijdag


## Dag 6 — Zaterdag


## Dag 7 — Zondag

