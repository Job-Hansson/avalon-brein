📅 DAGOVERZICHT — <Datum>

🕒 AGENDA
- Tijd — Afspraken
- Tijd — Taken

🔧 ACTIES VAN VANDAAG
[ ] Taken
[ ] Reminders

🎯 PRIORITEIT
1.
2.
3.

💸 FINANCIEEL
Potjes balances (indien opgevraagd)

🧠 STATUS
Energie:
Stress:
Motivatie:
