# AVALON Repository Skeleton

Structuur:
- rules-and-behaviour/behaviour.avl
- chats/ (wekelijkse chatlogs)
- logbooks/ (wekelijkse logboek excel + notulen)
- audit-log/ (wekelijkse audits)
- finance/ (optionele financiële sjablonen)
- analysis/ (dashboards & trend-analyse sjablonen)
